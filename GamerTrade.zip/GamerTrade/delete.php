<?php


$conn = mysqli_connect("localhost", "root", "", "gamertrade");

#once the delete button is clicked, grab the id from the table row and check if it is set. 
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
#map the id to a variable
$id = $_GET['id'];
#perform a stmt
$sql = "DELETE FROM items WHERE id = '$id' LIMIT 1";
$result = $conn->query($sql);
header("Location: removeitem.php");
}

?>